#include <iostream>
#include <cmath>
#include <string>
#include "GlyphLock.h"

using namespace std;

int main() {

glyphLock();

}